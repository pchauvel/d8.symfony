<?php
namespace Drupal\weather_module\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Response;


class WeatherNowController extends ControllerBase {
    public function __construct($get_weather){
        $this->get_weather = $get_weather;
    }


    public static function create(ContainerInterface $container) {
       return new self($container->get('weather_module.get_weather');
    }





    public function content($cityId)
    {


        return array(
            '#title' => 'Weather',
            '#theme' => 'weather_show',
            '#weather' => $this->get_weather->

        );
    }
}