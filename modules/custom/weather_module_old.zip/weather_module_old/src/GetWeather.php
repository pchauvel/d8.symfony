<?php

class GetWeather{
    const APP_ID = '39f1456ec4f79a7bd775644ee0632162'; //524901';
    public function get(){
        $url = sprintf(
            'https://api.openweathermap.org/data/2.5/weather?id=%s&appid=%s&units=metric',
            $cityId,
            self::APP_ID
        );
        $result = file_get_contents($url);
        $json_result = json_decode($result,true);
        //dump($json_result);
    }
}